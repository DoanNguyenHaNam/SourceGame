import UnityPy
import os
import sys

def extract_unity_file(filepath, output_dir):
    if not os.path.exists(filepath):
        print(f"[!] File không tồn tại: {filepath}")
        return

    env = UnityPy.load(filepath)

    for obj in env.objects:
        try:
            if obj.type.name == "Texture2D":
                data = obj.read()
                dest = os.path.join(output_dir, data.name + ".png")
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                image = data.image
                if image:
                    image.save(dest)
                    print(f"[+] Saved texture: {dest}")

            elif obj.type.name in ["TextAsset", "MonoBehaviour"]:
                data = obj.read()
                dest = os.path.join(output_dir, data.name + ".txt")
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with open(dest, "wb") as f:
                    f.write(data.script if hasattr(data, "script") else data.script_bytes)
                print(f"[+] Saved script/text: {dest}")

            elif obj.type.name == "AudioClip":
                data = obj.read()
                dest = os.path.join(output_dir, data.name + ".wav")
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with open(dest, "wb") as f:
                    f.write(data.audio_data)
                print(f"[+] Saved audio: {dest}")

            else:
                # Nếu cần hỗ trợ thêm loại, xử lý ở đây
                pass
        except Exception as e:
            print(f"[!] Lỗi khi extract {obj.type.name}: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python extract_unity.py <assetbundle_file> <output_dir>")
        sys.exit(1)

    file_path = sys.argv[1]
    output_path = sys.argv[2]
    extract_unity_file(file_path, output_path)
